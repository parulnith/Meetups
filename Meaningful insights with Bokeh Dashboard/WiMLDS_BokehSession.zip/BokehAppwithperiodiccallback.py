#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
from bokeh.plotting import figure, curdoc

def add_circles():
    """Add `num_points` circles to figure `fig`."""
    sample_plot.circle(x=np.random.normal(size=(10,)),
                       y=np.random.normal(size=(10,)))

bokeh_doc = curdoc()

sample_plot = figure(plot_height=400,
                     plot_width=400)

bokeh_doc.add_root(sample_plot)
bokeh_doc.add_periodic_callback(add_circles, 1000)
bokeh_doc.title = "Bokeh App with a periodic callback."

