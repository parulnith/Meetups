import numpy as np
from bokeh.plotting import figure, curdoc

bokeh_doc = curdoc()
sample_plot = figure(plot_height=400, plot_width=400)

sample_plot.circle(x=np.random.normal(size=(10,)),
                   y=np.random.normal(size=(10,)))

bokeh_doc.add_root(sample_plot)
bokeh_doc.title = "Sample Bokeh App"